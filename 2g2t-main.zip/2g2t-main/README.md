# Estudo do Segundo Trimestre
## Tema da Sala: Filme-(Cinema)
Leonardo de Mattos Ribeiro - N°21
